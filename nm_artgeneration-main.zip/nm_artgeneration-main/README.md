# nm_artgeneration
dataset link:
https://drive.google.com/drive/folders/1EzQYRjyAjxFQ5nHo3onUzXxAW3BnlUCs?usp=sharing
